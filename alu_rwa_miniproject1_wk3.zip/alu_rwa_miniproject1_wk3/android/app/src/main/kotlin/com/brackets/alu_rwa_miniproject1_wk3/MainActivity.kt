package com.brackets.alu_rwa_miniproject1_wk3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
